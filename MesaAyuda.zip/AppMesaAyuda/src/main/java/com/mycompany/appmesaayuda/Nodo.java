
package com.mycompany.appmesaayuda;


public class Nodo {
    private Tickets dato;
    private Nodo siguiente;

    
    public Nodo(Tickets dato) {
        this.dato = dato;
        this.siguiente = null;
    }

   
    public Tickets getDato() {
        return dato;
    }

    public void setDato(Tickets dato) {
        this.dato = dato;
    }

    public Nodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }

    
}
