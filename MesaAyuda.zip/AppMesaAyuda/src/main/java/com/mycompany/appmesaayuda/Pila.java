

package com.mycompany.appmesaayuda;


public class Pila {
    private Nodo cima;

    public Pila() {
        this.cima = null;
    }

    public boolean estaVacia() {
        return cima == null;
    }

    public void apilar(Tickets t) {
        Nodo nuevo = new Nodo(t);
        nuevo.setSiguiente(cima);
        cima = nuevo;
    }

    public Tickets desapilar() {
        if (estaVacia()) {
            return null;
        }
        Tickets t = cima.getDato();
        cima = cima.getSiguiente();
        return t;
    }

    public Nodo getCima() {
        return cima;
    }

    
}
