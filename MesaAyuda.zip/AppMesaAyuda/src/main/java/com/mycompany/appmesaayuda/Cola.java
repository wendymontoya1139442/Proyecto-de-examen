
package com.mycompany.appmesaayuda;


public class Cola {
    
    
private Nodo frente;
    private Nodo fin;

    public Cola() {
        this.frente = null;
        this.fin = null;
    }

    public boolean estaVacia() {
        return frente == null;
    }

    public void encolar(Tickets t) {
        Nodo nuevo = new Nodo(t);
        if (estaVacia()) {
            frente = nuevo;
            fin = nuevo;
        } else {
            fin.setSiguiente(nuevo);
            fin = nuevo;
        }
    }

    public Tickets desencolar() {
        if (estaVacia()) {
            return null;
        }
        Tickets t = frente.getDato();
        frente = frente.getSiguiente();
        if (frente == null) {
            fin = null;
        }
        return t;
    }

    public Nodo getFrente() {
        return frente;
    }
}
