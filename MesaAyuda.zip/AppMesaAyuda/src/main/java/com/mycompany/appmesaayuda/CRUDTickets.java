package com.mycompany.appmesaayuda;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;



public class CRUDTickets {
    private Archivo archivoManager = new Archivo();

    
    public void AtencionTickets(Cola colaEspera, String rutaArchivo) {
        List<Tickets> todosLosTickets = archivoManager.leerTodos(rutaArchivo);

        while (!colaEspera.estaVacia()) {
            Tickets tAtender = colaEspera.desencolar();
            tAtender.setEstado("atendido");

        
            for (Tickets t : todosLosTickets) {
                if (t.getIdTicket() == tAtender.getIdTicket()) {
                    t.setEstado("atendido");
                    break;
                }
            }
        }

        archivoManager.escribirTodos(rutaArchivo, todosLosTickets);
    }

    // Método 4: AuditoriaTickets (recibe la pila, crea auditados.txt y retorna pila con los que no cumplen)[cite: 1]
    public Pila AuditoriaTickets(Pila pilaAtendidos, String rutaAuditados) {
        Pila noCumplen = new Pila();
        List<Tickets> auditadosList = new java.util.ArrayList<>();

        while (!pilaAtendidos.estaVacia()) {
            Tickets t = pilaAtendidos.desapilar();
            if (t.getIdTicket() >= 1 && t.getIdTicket() <= 50) {
                auditadosList.add(t);
            } else {
                noCumplen.apilar(t);
            }
        }

        
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(rutaAuditados))) {
            for (Tickets t : auditadosList) {
                bw.write(t.toString());
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error al escribir auditados.txt: " + e.getMessage());
        }

        return noCumplen;
    }

    
}
