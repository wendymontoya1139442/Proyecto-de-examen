
package com.mycompany.appmesaayuda;

 
public class Tickets {
    private int idTicket;
    private String codIncidencia;
    private String estado;
    private String fechaReporte;

    // Constructor vacío (necesario para evitar errores de compilación)
    public Tickets() {
    }

    // Constructor con parámetros
    public Tickets(int idTicket, String codIncidencia, String estado, String fechaReporte) {
        this.idTicket = idTicket;
        this.codIncidencia = codIncidencia;
        this.estado = estado;
        this.fechaReporte = fechaReporte;
    }

    // Getters y Setters
    public int getIdTicket() {
        return idTicket;
    }

    public void setIdTicket(int idTicket) {
        this.idTicket = idTicket;
    }

    public String getCodIncidencia() {
        return codIncidencia;
    }

    public void setCodIncidencia(String codIncidencia) {
        this.codIncidencia = codIncidencia;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getFechaReporte() {
        return fechaReporte;
    }

    public void setFechaReporte(String fechaReporte) {
        this.fechaReporte = fechaReporte;
    }

    @Override
    public String toString() {
        return idTicket + "," + codIncidencia + "," + estado + "," + fechaReporte;
    }
}
