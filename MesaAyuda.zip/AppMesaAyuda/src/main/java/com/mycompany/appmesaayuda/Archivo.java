package com.mycompany.appmesaayuda;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;




public class Archivo {
    public List<Tickets> leerTodos(String rutaArchivo) {
        List<Tickets> lista = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (linea.trim().isEmpty()) continue;
                String[] datos = linea.split(",");
                lista.add(new Tickets(
                    Integer.parseInt(datos[0].trim()),
                    datos[1].trim(),
                    datos[2].trim(),
                    datos[3].trim()
                ));
            }
        } catch (IOException e) {
            System.out.println("Error al leer archivo general: " + e.getMessage());
        }
        return lista;
    }

    public void escribirTodos(String rutaArchivo, List<Tickets> lista) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(rutaArchivo))) {
            for (Tickets t : lista) {
                bw.write(t.toString());
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error al escribir archivo general: " + e.getMessage());
        }
    }
}

    

