package com.mycompany.appmesaayuda;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;



public class ManejoCola {
    public Cola extraccionInformacionTicketsEspera(String rutaArchivo) {
        Cola colaEspera = new Cola();
        try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (linea.trim().isEmpty()) continue;
                String[] datos = linea.split(",");
                int id = Integer.parseInt(datos[0].trim());
                String cod = datos[1].trim();
                String estado = datos[2].trim();
                String fecha = datos[3].trim();

                if (estado.equalsIgnoreCase("en espera")) {
                    colaEspera.encolar(new Tickets(id, cod, estado, fecha));
                }
            }
        } catch (IOException e) {
            System.out.println("Error al leer archivo para la cola: " + e.getMessage());
        }
        return colaEspera;
    }

    
    
}
