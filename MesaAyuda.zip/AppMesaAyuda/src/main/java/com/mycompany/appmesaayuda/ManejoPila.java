package com.mycompany.appmesaayuda;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;



public class ManejoPila {
    public Pila extraccionInformacionTicketsAtendidos(String rutaArchivo) {
        Pila pilaAtendidos = new Pila();
        try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (linea.trim().isEmpty()) continue;
                String[] datos = linea.split(",");
                int id = Integer.parseInt(datos[0].trim());
                String cod = datos[1].trim();
                String estado = datos[2].trim();
                String fecha = datos[3].trim();

                if (estado.equalsIgnoreCase("atendido")) {
                    pilaAtendidos.apilar(new Tickets(id, cod, estado, fecha));
                }
            }
        } catch (IOException e) {
            System.out.println("Error al leer archivo para la pila: " + e.getMessage());
        }
        return pilaAtendidos;
    }
}
