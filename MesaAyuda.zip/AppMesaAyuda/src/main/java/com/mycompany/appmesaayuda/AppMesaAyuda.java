package com.mycompany.appmesaayuda;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;



public class AppMesaAyuda {

    private static final String ARCHIVO_INGRESADOS = "TicketsIngresados.txt";
    private static final String ARCHIVO_AUDITADOS = "auditados.txt";
    
    public static void main(String[] args) {
     crearArchivoPrueba();
     ManejoCola manejoCola = new ManejoCola();
        ManejoPila  manejoPila = new ManejoPila();
        CRUDTickets crud = new CRUDTickets();

        System.out.println("==================================================");
        System.out.println("--- ESTADO INICIAL DE 'TicketsIngresados.txt' ---");
        imprimirArchivo(ARCHIVO_INGRESADOS);

      
        System.out.println("\n--------------------------------------------------");
        System.out.println("1. Ejecutando extraccionInformacionTicketsEspera...");
        Cola colaEspera = manejoCola.extraccionInformacionTicketsEspera(ARCHIVO_INGRESADOS);
        
        System.out.println("Contenido de la Cola extraída:");
        Nodo actualC = colaEspera.getFrente();
        while (actualC != null) {
            System.out.println("   -> " + actualC.getDato());
            actualC = actualC.getSiguiente();
        }

        
        System.out.println("\n--------------------------------------------------");
        System.out.println("2. Ejecutando AtencionTickets...");
        crud.AtencionTickets(colaEspera, ARCHIVO_INGRESADOS);

        System.out.println("\n--- ESTADO DE 'TicketsIngresados.txt' TRAS ATENDER ---");
        imprimirArchivo(ARCHIVO_INGRESADOS);

        
        System.out.println("\n--------------------------------------------------");
        System.out.println("3. Ejecutando extraccionInformacionTicketsAtendidos...");
        Pila pilaAtendidos = manejoPila.extraccionInformacionTicketsAtendidos(ARCHIVO_INGRESADOS);

        System.out.println("Contenido de la Pila extraída:");
        Nodo actualP = pilaAtendidos.getCima();
        while (actualP != null) {
            System.out.println("   -> " + actualP.getDato());
            actualP = actualP.getSiguiente();
        }

       
        System.out.println("\n--------------------------------------------------");
        System.out.println("4. Ejecutando AuditoriaTickets...");
        Pila noCumplen = crud.AuditoriaTickets(pilaAtendidos, ARCHIVO_AUDITADOS);

        System.out.println("\n--- CONTENIDO GENERADO EN 'auditados.txt' (ID entre 1 y 50) ---");
        imprimirArchivo(ARCHIVO_AUDITADOS);

        System.out.println("\n--- PILA RETORNADA CON TICKETS QUE NO CUMPLIERON ---");
        Nodo actualNC = noCumplen.getCima();
        if (actualNC == null) {
            System.out.println("   (Ninguno)");
        } else {
            while (actualNC != null) {
                System.out.println("   -> " + actualNC.getDato());
                actualNC = actualNC.getSiguiente();
            }
        }
        System.out.println("==================================================");
    }

    private static void crearArchivoPrueba() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ARCHIVO_INGRESADOS))) {
            bw.write("15,INC-001,en espera,2026-10-01\n");
            bw.write("45,INC-002,atendido,2026-10-02\n");
            bw.write("60,INC-003,en espera,2026-10-03\n");
            bw.write("30,INC-004,atendido,2026-10-04\n");
        } catch (IOException e) {
            System.out.println("Error creando archivo de prueba: " + e.getMessage());
        }
    }

    private static void imprimirArchivo(String ruta) {
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                System.out.println("   [TXT] " + linea);
            }
        } catch (IOException e) {
            System.out.println("   (No se pudo leer el archivo)");
        }
    }

    }

